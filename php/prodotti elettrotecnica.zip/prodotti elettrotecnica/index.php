<?php include 'php/header.php';?>

<!-- Main Content -->
<main class="container text-center my-5 flex-grow-1">
    <h2 class="mb-4">Benvenuto nel negozio di elettrotecnica!</h2>
    <p>compra tansistors</p>
    <img src="immagini/corriere.png" alt="Immagine di un negozio" class="img-fluid rounded shadow mt-4">
</main>
<?php
?>

<?php include 'php/footer.php'; ?>
