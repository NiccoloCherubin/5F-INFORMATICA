<!-- Footer -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <p class="mb-0">© 2025 elettrotecnica. Tutti i diritti riservati.</p>
</footer>
<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
