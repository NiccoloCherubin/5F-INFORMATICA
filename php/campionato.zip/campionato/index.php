<?php
include 'php/db.php';
include 'php/header.php';
?>

<main class="container mt-5 text-center">
    <h2>Benvenuto al Campionato Automobilistico</h2>
    <p>Gestisci e visualizza tutte le informazioni relative alle gare, i piloti e le case automobilistiche.</p>
</main>

<?php include 'php/footer.php'; ?>
